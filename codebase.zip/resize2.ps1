Add-Type -AssemblyName System.Drawing
$img = [System.Drawing.Image]::FromFile('C:\Internship\spare-part-stock\mobile\sparepart_mobile\flutter_03.png')
$ratio = [Math]::Min(540.0 / $img.Width, 960.0 / $img.Height)
$newWidth = [int]($img.Width * $ratio)
$newHeight = [int]($img.Height * $ratio)
$thumb = New-Object System.Drawing.Bitmap($newWidth, $newHeight)
$graphics = [System.Drawing.Graphics]::FromImage($thumb)
$graphics.DrawImage($img, 0, 0, $newWidth, $newHeight)
$thumb.Save('C:\Internship\spare-part-stock\emulator-dashboard.jpg', [System.Drawing.Imaging.ImageFormat]::Jpeg)
$graphics.Dispose()
$thumb.Dispose()
$img.Dispose()
Write-Host "Done: $newWidth x $newHeight"