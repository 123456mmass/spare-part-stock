# Mobile Architecture — Spare Part Stock

This document describes the mobile API layer for the Spare Part Stock application, intended for a future Flutter app used by warehouse staff.

## Overview

```
┌─────────────┐    Bearer JWT    ┌──────────────────┐
│   Flutter   │ ────────────────→│  /api/mobile/*   │
│   Mobile    │←───────────────── │  (Next.js BFF)   │
└─────────────┘   JSON response  └────────┬─────────┘
                                          │ Prisma
                                      ┌───▼──────┐
                                      │  dev.db  │
                                      │ (SQLite) │
                                      └──────────┘
```

- Mobile API lives at `/api/mobile/*` alongside the existing web API.
- Auth is Bearer JWT (no httpOnly cookies).
- The Flutter app stores the token locally (e.g., SharedPreferences, flutter_secure_storage).
- All mobile endpoints return JSON; no HTML pages.

---

## Auth Flow

### 1. Login

```http
POST /api/mobile/auth/login
Content-Type: application/json

{ "username": "admin", "password": "admin123" }
```

**Success (200):**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "expiresAt": "2026-05-16T10:30:00.000Z",
  "user": { "id": "...", "username": "admin", "name": "Admin", "role": "ADMIN" }
}
```

**Failure (401):**
```json
{ "error": "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง" }
```

Flutter stores `token` and `expiresAt` locally. On app resume, call `GET /api/mobile/auth/me` to validate.

### 2. Validate Token (App Resume)

```http
GET /api/mobile/auth/me
Authorization: Bearer <token>
```

**Success (200):**
```json
{ "user": { "id": "...", "username": "admin", "name": "Admin", "role": "ADMIN" } }
```

**Failure (401):**
```json
{ "error": "Unauthorized" }
```

### 3. Logout

```http
POST /api/mobile/auth/logout
Authorization: Bearer <token>
```

```json
{ "success": true }
```

Flutter must delete the stored token locally. Server-side token revocation is NOT implemented (no session table).

---

## Token Security

| Property | Value |
|----------|-------|
| Algorithm | HS256 |
| Expiry | 7 days |
| Payload | `{ userId, username, role, expiresAt }` |
| Revocation | Not implemented |
| Shared with web session | Yes — same JWT, same secret |

**No revocation** means a stolen token is valid for up to 7 days. If revocation is needed, add a `MobileSession` table that maps tokens to active/inactive status.

---

## Role / Permission Matrix

| Action | STAFF | ADMIN |
|--------|-------|-------|
| Search parts | ✓ | ✓ |
| View part detail | ✓ | ✓ |
| Scan QR code | ✓ | ✓ |
| Stock In | ✓ | ✓ |
| Stock Out | ✓ | ✓ |
| Adjustment | ✗ | ✓ |
| Recent movements | ✓ | ✓ |
| Create part | ✗ | ✓ |
| Edit/Delete part | ✗ | ✓ |
| Import Excel | ✗ | ✓ |
| Manage categories | ✗ | ✓ |

Server enforces role — the client must never trust its own `role` field.

---

## API Endpoints

### Auth

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | `/api/mobile/auth/login` | None | Login, returns token + expiresAt |
| GET | `/api/mobile/auth/me` | Bearer | Validate token, get current user |
| POST | `/api/mobile/auth/logout` | Bearer | No-op logout |
| POST | `/api/mobile/auth/change-password` | Bearer | Change password (works with temp password) |

### Parts

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | `/api/mobile/parts` | Bearer | Search/list parts (paginated) |
| GET | `/api/mobile/parts/by-code/[code]` | Bearer | Resolve scanned code to part |
| GET | `/api/mobile/parts/[id]` | Bearer | Get part by ID |
| GET | `/api/mobile/public/parts/lookup` | None | Read-only lookup by code (QR/barcode/partNumber) |

#### `GET /api/mobile/parts`

Query params: `search`, `categoryId`, `stockStatus` (out-of-stock | low-stock | in-stock), `page` (default 1), `limit` (default 20, max 100).

```json
{
  "parts": [
    { "id": "...", "partNumber": "ABC-001", "partName": "Bearing", "quantity": 10, "minimumQuantity": 5, "unit": "pcs", "category": { "name": "Fasteners" }, "location": "A-01" }
  ],
  "total": 60,
  "page": 1,
  "limit": 20,
  "totalPages": 3
}
```

#### `GET /api/mobile/parts/by-code/[code]`

Scanned code resolution order:
1. **QR URL path**: `/parts/cmox7l9j200009wfx0lui6t9p` → looks up by `id`
2. **Full URL**: `http://localhost:3000/parts/cmox7l9j200009wfx0lui6t9p` → extracts ID
3. **Direct partNumber**: `ABC-001` → looks up by `partNumber` field
4. **Future barcodeValue**: Add `barcodeValue` field to schema → add lookup here

**Success (200):** Part object with `category` and last 10 `movements`.

**Failure (404):**
```json
{ "error": "ไม่พบอะไหล่จากรหัสที่สแกน" }
```

### Movements

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | `/api/mobile/movements` | Bearer | Recent movements |
| POST | `/api/mobile/movements` | Bearer | Create stock movement |
| POST | `/api/mobile/sync` | Bearer | Offline sync stub (501) |

#### `GET /api/mobile/movements`

Query params: `limit` (default 20, max 50), `partId` (optional).

```json
{
  "movements": [
    { "id": "...", "type": "STOCK_OUT", "quantityBefore": 10, "quantityAfter": 7, "quantityChange": -3, "note": "ใช้งาน", "createdAt": "2026-05-09T10:30:00.000Z", "part": { "partNumber": "ABC-001", "partName": "Bearing" }, "user": { "name": "Staff" } }
  ]
}
```

#### `POST /api/mobile/movements`

Body:
```json
{ "partId": "...", "type": "STOCK_OUT", "quantity": 3, "note": "ใช้งาน" }
```

`type` must be `STOCK_IN`, `STOCK_OUT`, or `ADJUSTMENT`. STAFF can only use `STOCK_IN` and `STOCK_OUT`. `ADJUSTMENT` requires ADMIN.

**Success (201):**
```json
{
  "movement": {
    "id": "...",
    "type": "STOCK_OUT",
    "quantityBefore": 10,
    "quantityAfter": 7,
    "quantityChange": -3,
    "note": "ใช้งาน",
    "createdAt": "2026-05-09T10:30:00.000Z",
    "part": { "partNumber": "ABC-001", "partName": "Bearing", "quantity": 7 },
    "user": { "name": "Staff" }
  },
  "partQuantity": 7
}
```

**Error responses:**

| Status | Condition |
|--------|-----------|
| 400 | `PART_NOT_FOUND`, `INSUFFICIENT_STOCK`, `NEGATIVE_STOCK`, validation error |
| 401 | No/invalid token |
| 403 | STAFF tries ADJUSTMENT |
| 500 | Server error |

---

## Error Format

All errors follow this shape:

```json
{ "error": "ข้อความแสดงข้อผิดพลาด" }
```

Validation errors include details:

```json
{ "error": "ข้อมูลไม่ถูกต้อง", "details": [...] }
```

---

## Offline Sync Design (Future)

When implementing offline support, the `POST /api/mobile/sync` endpoint will accept:

```json
{
  "mutations": [
    { "clientMutationId": "uuid-v4", "type": "STOCK_OUT", "partId": "...", "quantity": 3, "note": "offline scan", "createdAt": "..." }
  ],
  "lastSyncAt": "2026-05-09T08:00:00.000Z"
}
```

### Idempotency

Each mutation must include a `clientMutationId` (UUID v4 generated on the client). Before applying any mutation, the server checks if a movement with that `clientMutationId` already exists. If it does, the mutation is skipped (not re-applied). This prevents duplicate stock movements when the same mutation is submitted multiple times (e.g., network retry).

### Conflict Resolution

- Movements are applied in `createdAt` order.
- If a conflict is detected (e.g., stock goes negative due to offline movements), return the conflict in the response and let the client resolve it.
- `lastSyncAt` is returned in the response so the client can persist the sync timestamp.

### Prerequisite Changes

To implement full offline sync, the following schema changes are needed (separate feature task):
1. Add `clientMutationId` field to `StockMovement` model (unique, optional).
2. Add `syncedAt` field to `StockMovement` model.
3. Add the sync endpoint implementation.

---

## Anonymous Part Lookup (No Auth)

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | `/api/mobile/public/parts/lookup?code=...` | None | Read-only part lookup by QR/barcode/partNumber |

Query param: `code` — the scanned QR code, barcode, or part number.

**Success (200):**
```json
{
  "part": {
    "id": "...",
    "partNumber": "ABC-001",
    "partName": "Bearing",
    "description": "...",
    "quantity": 10,
    "minimumQuantity": 5,
    "unit": "pcs",
    "location": "A-01",
    "imageUrl": null,
    "category": { "id": "...", "name": "Fasteners" },
    "stockStatus": "IN_STOCK"
  },
  "canEdit": false,
  "requiresLoginFor": ["STOCK_IN", "STOCK_OUT", "ADJUSTMENT", "EDIT_PART"]
}
```

**Error responses:**

| Status | Condition |
|--------|-----------|
| 400 | Missing `code` parameter |
| 404 | Part not found |

This endpoint requires no authentication. It is designed for mobile users who want to scan a QR code and view stock levels without logging in. Stock movements and edits still require a Bearer token.

### Temporary Passwords

When an admin creates a user or resets a password, the system generates a random 6-character one-time password. This password is shown to the admin exactly once and must be communicated to the user immediately. The user is forced to change this password on first login. The temporary password should not be stored or reused — it is a short-lived credential valid only until the user sets their own password.

---

## Flutter Integration Guide

### Store Token

```dart
// On login success
await SecureStorage.write(key: 'auth_token', value: response.token);
await SecureStorage.write(key: 'token_expires_at', value: response.expiresAt);
```

### Send Authenticated Requests

```dart
final token = await SecureStorage.read(key: 'auth_token');
final response = await dio.get('/api/mobile/parts', options: Options(
  headers: { 'Authorization': 'Bearer $token' },
));
```

### Handle 401

If `GET /api/mobile/auth/me` returns 401, clear the stored token and redirect to login.

### Token Expiry

`expiresAt` is returned on login. Compare with `DateTime.now()` to proactively re-login before the token expires. Alternatively, always call `/api/mobile/auth/me` on app resume and handle 401.

---

## Data Models

### User
```ts
{ id: string; username: string; name: string; role: "ADMIN" | "STAFF"; mustChangePassword: boolean }
```

### Part
```ts
{ id: string; partNumber: string; partName: string; description?: string; quantity: number; minimumQuantity: number; unit: string; location?: string; imageUrl?: string; category?: { id: string; name: string } }
```

### StockMovement
```ts
{ id: string; type: "STOCK_IN" | "STOCK_OUT" | "ADJUSTMENT"; quantityBefore: number; quantityAfter: number; quantityChange: number; note?: string; createdAt: string; part: { partNumber: string; partName: string; quantity: number }; user: { name: string } }
```

---

## Files Reference

| File | Purpose |
|------|---------|
| `src/lib/session.ts` | `signSessionToken()`, `getSessionFromRequest()` |
| `src/lib/auth.ts` | `requireAuthFromRequest()`, `requireRoleFromRequest()`, `requireAuthFromRequestAllowPasswordChange()` |
| `src/lib/stock.ts` | `createStockMovement()`, `StockError` |
| `src/lib/part-lookup.ts` | `resolvePartFromCode()` |
| `src/app/api/mobile/auth/login/route.ts` | Mobile login |
| `src/app/api/mobile/auth/me/route.ts` | Token validation |
| `src/app/api/mobile/auth/logout/route.ts` | No-op logout |
| `src/app/api/mobile/auth/change-password/route.ts` | Change password |
| `src/app/api/mobile/parts/route.ts` | Parts list/search |
| `src/app/api/mobile/parts/by-code/[code]/route.ts` | Code lookup |
| `src/app/api/mobile/parts/[id]/route.ts` | Part by ID |
| `src/app/api/mobile/movements/route.ts` | Create/recent movements |
| `src/app/api/mobile/sync/route.ts` | Sync stub (501) |
| `src/app/api/mobile/public/parts/lookup/route.ts` | Public read-only lookup |