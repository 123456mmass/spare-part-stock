@echo off
title Spare Part Stock - Dev Server
cd /d "%~dp0"

echo ========================================
echo   Spare Part Stock - Dev Server
echo ========================================
echo.

REM Check node_modules
if not exist "node_modules\" (
    echo [1/3] Installing dependencies...
    call npm install
    if %errorlevel% neq 0 (
        echo ERROR: npm install failed
        pause
        exit /b 1
    )
    echo.
)

REM Generate Prisma client
echo [2/3] Generating Prisma client...
call npx prisma generate
if %errorlevel% neq 0 (
    echo ERROR: prisma generate failed
    pause
    exit /b 1
)
echo.

REM Check database
if not exist "dev.db" (
    echo [3/3] Creating database + seed...
    call npx prisma migrate dev --name init
    call npm run db:seed
    echo.
)

REM Kill any existing process on port 3000
echo Cleaning up port 3000...
for /f "tokens=5" %%a in ('netstat -ano 2^>nul ^| findstr ":3000 " ^| findstr "LISTENING"') do (
    taskkill /PID %%a /F >nul 2>nul
)
echo.

echo ========================================
echo   Server: http://localhost:3000
echo   Press Ctrl+C to stop
echo ========================================
echo.

REM Start dev server
npm run dev

pause
