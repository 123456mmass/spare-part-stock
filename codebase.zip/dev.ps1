# Spare Part Stock - Dev Server Script
# Run: .\dev.ps1
# หรือ: powershell -ExecutionPolicy Bypass -File dev.ps1

$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Spare Part Stock - Dev Server" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Check Node.js
try {
    $nodeVersion = node --version 2>$null
    if (-not $nodeVersion) {
        Write-Host "ERROR: Node.js not found" -ForegroundColor Red
        exit 1
    }
    Write-Host "Node.js: $nodeVersion" -ForegroundColor Green
} catch {
    Write-Host "ERROR: Node.js not found" -ForegroundColor Red
    exit 1
}

# Check .env
if (-not (Test-Path ".env")) {
    Write-Host "WARNING: .env not found, copying .env.example..." -ForegroundColor Yellow
    if (Test-Path ".env.example") {
        Copy-Item ".env.example" ".env"
        Write-Host "Created .env from .env.example" -ForegroundColor Green
    } else {
        Write-Host "ERROR: No .env or .env.example found" -ForegroundColor Red
        exit 1
    }
}

# Check node_modules
if (-not (Test-Path "node_modules")) {
    Write-Host "Installing dependencies..." -ForegroundColor Yellow
    npm install
}

# Generate Prisma client
Write-Host "Generating Prisma client..." -ForegroundColor Yellow
npx prisma generate

# Check database
if (-not (Test-Path "dev.db")) {
    Write-Host "Database not found, running migration + seed..." -ForegroundColor Yellow
    npx prisma migrate dev --name init
    npm run db:seed
}

Write-Host ""
Write-Host "Starting dev server on http://localhost:3000" -ForegroundColor Green
Write-Host "Press Ctrl+C to stop" -ForegroundColor Gray
Write-Host ""

# Kill any existing process on port 3000
$existing = netstat -ano 2>$null | Select-String ":3000.*LISTENING" | ForEach-Object { ($_ -split '\s+')[-1] } | Select-Object -Unique
foreach ($pid in $existing) {
    Write-Host "Killing existing process on port 3000 (PID: $pid)..." -ForegroundColor Yellow
    taskkill /PID $pid /F 2>$null | Out-Null
    Start-Sleep 1
}

# Start dev server
npm run dev
