Add-Type -AssemblyName System.Drawing
$img = [System.Drawing.Image]::FromFile('C:\Internship\spare-part-stock\mobile\sparepart_mobile\flutter_01.png')
$thumb = $img.GetThumbnailImage(540, 960, $null, $null)
$thumb.Save('C:\Internship\spare-part-stock\emulator-screen-small.png')
$img.Dispose()
Write-Host "Done"