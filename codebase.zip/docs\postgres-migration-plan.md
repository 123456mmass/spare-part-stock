# PostgreSQL Migration Plan

This document describes the steps to migrate the Spare Part Stock application from SQLite to PostgreSQL.

## Overview

| Property | Current | Target |
|----------|---------|--------|
| Database | SQLite | PostgreSQL |
| Provider | `sqlite` | `postgresql` |
| ORM | Prisma | Prisma |
| Connection | Local file (`dev.db`) | Hosted PostgreSQL |

---

## When to Migrate

Consider migrating when:
- The app outgrows single-instance development
- Multiple concurrent users stress SQLite's write limitations
- Deploying to a hosted environment (Vercel, Railway, Render, etc.)
- Team members need simultaneous database access
- Data size exceeds a few GB

---

## Prerequisites

- PostgreSQL 14+ instance (local or hosted)
- Connection URL: `postgresql://user:password@host:5432/spare_part_stock`
- Backup of existing `prisma/dev.db` SQLite file

---

## Phase 1: Environment Variables

Create a `.env.postgresql` file (do NOT commit this to git):

```env
DATABASE_URL="postgresql://user:password@host:5432/spare_part_stock"
```

Update `.env` to point to PostgreSQL when ready to switch:
```env
DATABASE_URL="postgresql://user:password@host:5432/spare_part_stock"
```

---

## Phase 2: Update Prisma Schema

### `prisma/schema.prisma`

Change the `datasource` block:
```prisma
datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}
```

### SQLite → PostgreSQL Differences

**Auto-increment**: SQLite uses `@default(autoincrement())` on `String @id` fields. PostgreSQL does not support this on String. The `@default(cuid())` pattern used in this project is already compatible — no change needed for ID fields.

**Unique constraint on nullable field**: SQLite allows multiple `NULL` values on a unique nullable column. PostgreSQL also allows this by default. No schema change needed for `barcodeValue` unique.

**Text vs String**: Prisma maps both to `TEXT` in PostgreSQL. No change needed.

**Index names**: Auto-generated index names may conflict if migrating with existing indexes. Use `@@index([column], name: "custom_name")` to avoid conflicts.

### Validate Schema
```bash
npx prisma validate
```

---

## Phase 3: Data Migration

### Option A: Fresh Migration (recommended for development)

```bash
# 1. Ensure PostgreSQL is running
# 2. Set DATABASE_URL to PostgreSQL
export DATABASE_URL="postgresql://user:password@host:5432/spare_part_stock"

# 3. Push schema directly (no migration history)
npx prisma db push --force-reset

# 4. Seed data if needed
npx prisma db seed
```

### Option B: Migrate Existing Data

Use `pgloader` to transfer data from SQLite to PostgreSQL:

```bash
# Install pgloader
brew install pgloader  # macOS
# or: apt install pgloader  # Linux

# Create load file
LOAD DATABASE
  FROM sqlite://dev.db
  INTO postgresql://user:password@host:5432/spare_part_stock
WITH include no drop, truncate, create no tables, create no indexes, preserve index names
SET maintenance_work_mem to '128MB', work_mem to '12MB';

# Run
pgloader load.load
```

Then run Prisma migrations to create indexes:
```bash
npx prisma migrate deploy
```

---

## Phase 4: Indexes

After migrating data, ensure indexes are created. Prisma migrations will create them automatically on `migrate deploy`. If using `db push`, manually run:

```bash
npx prisma db push  # Also creates indexes defined in schema
```

---

## Phase 5: Application Testing

### Smoke Tests

1. **Auth**: Login as admin, create user, change password
2. **Parts CRUD**: Create part with barcode, edit, delete
3. **Stock movements**: STOCK_IN, STOCK_OUT, ADJUSTMENT
4. **Excel import/export**: Import parts with barcode, export all parts
5. **Dashboard**: Verify stats, low-stock alert panel
6. **Mobile API**: Public lookup, authenticated requests

### Connection Issues

If you see `Can't reach database at host:5432`:
- Verify PostgreSQL is running: `pg_isready -h host -p 5432`
- Check firewall rules
- Verify `DATABASE_URL` is correctly set and loaded

---

## Phase 6: Rollback Plan

To revert to SQLite:

1. Keep the SQLite backup file (`prisma/dev.db.backup`)
2. Restore `.env` to:
   ```env
   DATABASE_URL="file:./dev.db"
   ```
3. Restart the application
4. If PostgreSQL data needs to be preserved, export it first:
   ```bash
   pg_dump -h host -U user -d spare_part_stock > backup.sql
   ```

---

## Schema Differences to Address

### Unique Constraint on `barcodeValue`

SQLite allows multiple `NULL` values in a unique nullable column. PostgreSQL does too — no change needed.

### `cuid()` vs `uuid()`

The current `@default(cuid())` pattern works with PostgreSQL. If switching to `uuid()`, update all ID field defaults:
```prisma
id String @id @default(uuid())
```

### Enum Handling

SQLite does not have native enums. Prisma emulates them. PostgreSQL has native enum types. Prisma handles the conversion automatically, but the enum values are stored as strings in both cases.

---

## Validation Checklist

After migration, verify:

- [ ] `npx prisma validate` passes
- [ ] `npx prisma db push --dry-run` shows no issues
- [ ] App starts without connection errors
- [ ] Login/logout works
- [ ] Parts CRUD with barcode works
- [ ] Stock movements record correctly
- [ ] Excel import with barcode column works
- [ ] Dashboard stats render correctly
- [ ] Mobile public lookup works
- [ ] No negative stock values introduced

---

## Performance Considerations

- PostgreSQL connection pooling: Set `connection_limit` in `schema.prisma` generator or use PgBouncer for high traffic
- Indexes: Ensure indexes on `partNumber`, `categoryId`, `location`, `partName` are created
- Query optimization: Prisma's `findMany` with `take`/`skip` for pagination already uses indexes efficiently
